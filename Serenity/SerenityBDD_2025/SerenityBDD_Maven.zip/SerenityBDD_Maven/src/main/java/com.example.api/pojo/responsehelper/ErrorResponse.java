package com.example.api.pojo.responsehelper;

public class ErrorResponse {
    private String error;

    // Getters and Setters
    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }
}

